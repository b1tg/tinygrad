#include <stdint.h>
#include <stdio.h>
#include <string.h>

extern uint32_t RegisterAscendBinary(const char *fileBuf, size_t fileSize, uint32_t type, void **handle);
extern uint32_t LaunchAscendKernel(void *handle, const uint64_t key, const uint32_t blockDim, void **args,
                                   uint32_t size, const void *stream);
extern uint32_t UnregisterAscendBinary(void *hdl);
extern uint32_t LaunchAscendKernelForVectorCore(const char *opType, void *handle, const uint64_t key,
                                                void **args, uint32_t size, const void *stream,
                                                int enbaleProf, uint32_t aicBlockDim, uint32_t aivBlockDim,
                                                uint32_t aivBlockDimOffset);

int32_t my_register(const char *buf, size_t sz, uint32_t type, void **handle) {
    return RegisterAscendBinary(buf, sz, type, handle);
}

int32_t my_launch(void *handle, uint64_t key, uint32_t blockDim, void **args, uint32_t size, const void *stream) {
    return LaunchAscendKernel(handle, key, blockDim, args, size, stream);
}

int32_t my_launch_vec(const char *opType, void *handle, uint64_t key, void **args, uint32_t size, const void *stream,
                      uint32_t aivBlockDim) {
    return LaunchAscendKernelForVectorCore(opType, handle, key, args, size, stream, 0, 0, aivBlockDim, 0);
}

int32_t my_unregister(void *hdl) {
    return UnregisterAscendBinary(hdl);
}
