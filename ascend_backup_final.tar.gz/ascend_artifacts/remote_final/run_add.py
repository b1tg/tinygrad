import ctypes, os, sys, struct

acl = ctypes.CDLL("libascendcl.so")

acl.aclInit.argtypes = [ctypes.c_char_p]; acl.aclInit.restype = ctypes.c_int
acl.aclFinalize.argtypes = []; acl.aclFinalize.restype = ctypes.c_int
acl.aclrtSetDevice.argtypes = [ctypes.c_int]; acl.aclrtSetDevice.restype = ctypes.c_int
acl.aclrtResetDevice.argtypes = [ctypes.c_int]; acl.aclrtResetDevice.restype = ctypes.c_int
acl.aclrtCreateStream.argtypes = [ctypes.POINTER(ctypes.c_void_p)]; acl.aclrtCreateStream.restype = ctypes.c_int
acl.aclrtDestroyStream.argtypes = [ctypes.c_void_p]; acl.aclrtDestroyStream.restype = ctypes.c_int
acl.aclrtSynchronizeStream.argtypes = [ctypes.c_void_p]; acl.aclrtSynchronizeStream.restype = ctypes.c_int
acl.aclrtMalloc.argtypes = [ctypes.POINTER(ctypes.c_void_p), ctypes.c_size_t, ctypes.c_int]; acl.aclrtMalloc.restype = ctypes.c_int
acl.aclrtFree.argtypes = [ctypes.c_void_p]; acl.aclrtFree.restype = ctypes.c_int
acl.aclrtMemcpy.argtypes = [ctypes.c_void_p, ctypes.c_size_t, ctypes.c_void_p, ctypes.c_size_t, ctypes.c_int]; acl.aclrtMemcpy.restype = ctypes.c_int
acl.aclrtCreateBinary.argtypes = [ctypes.c_void_p, ctypes.c_size_t]; acl.aclrtCreateBinary.restype = ctypes.c_void_p
acl.aclrtBinaryLoad.argtypes = [ctypes.c_void_p, ctypes.POINTER(ctypes.c_void_p)]; acl.aclrtBinaryLoad.restype = ctypes.c_int
acl.aclrtBinaryGetFunction.argtypes = [ctypes.c_void_p, ctypes.c_char_p, ctypes.POINTER(ctypes.c_void_p)]; acl.aclrtBinaryGetFunction.restype = ctypes.c_int
acl.aclrtLaunchKernel.argtypes = [ctypes.c_void_p, ctypes.c_uint, ctypes.c_void_p, ctypes.c_size_t, ctypes.c_void_p]; acl.aclrtLaunchKernel.restype = ctypes.c_int

H2D, D2H = 1, 2

def ok(r, what):
    if r != 0: print(f"[X] {what}: rc={r}"); sys.exit(1)

ok(acl.aclInit(None), "aclInit")
ok(acl.aclrtSetDevice(0), "aclrtSetDevice")
stream = ctypes.c_void_p()
ok(acl.aclrtCreateStream(ctypes.byref(stream)), "CreateStream")

with open(sys.argv[1], "rb") as f: data = f.read()
bh = acl.aclrtCreateBinary(data, len(data))
binH = ctypes.c_void_p()
ok(acl.aclrtBinaryLoad(bh, ctypes.byref(binH)), "BinaryLoad")
func = ctypes.c_void_p()
ok(acl.aclrtBinaryGetFunction(binH, b"add_custom", ctypes.byref(func)), "GetFunction")
print(f"[ok] func handle = {func.value:#x}")

N = 48 * 256
nbytes = N * 4
x_h = (ctypes.c_float * N)(*[i * 1.1 for i in range(N)])
y_h = (ctypes.c_float * N)(*[i + 3.4 for i in range(N)])
z_h = (ctypes.c_float * N)()

x_d = ctypes.c_void_p(); ok(acl.aclrtMalloc(ctypes.byref(x_d), nbytes, 0), "malloc x")
y_d = ctypes.c_void_p(); ok(acl.aclrtMalloc(ctypes.byref(y_d), nbytes, 0), "malloc y")
z_d = ctypes.c_void_p(); ok(acl.aclrtMalloc(ctypes.byref(z_d), nbytes, 0), "malloc z")

ok(acl.aclrtMemcpy(x_d, nbytes, x_h, nbytes, H2D), "H2D x")
ok(acl.aclrtMemcpy(y_d, nbytes, y_h, nbytes, H2D), "H2D y")

# kernel signature: GM_ADDR x, GM_ADDR y, GM_ADDR z, uint32_t total_length
# __CCE_KernelArgSize = 32 (8-byte aligned: 3 ptrs + uint32 + 4 pad)
args = bytearray(32)
struct.pack_into("QQQI", args, 0, x_d.value, y_d.value, z_d.value, N)
abuf = (ctypes.c_byte * 32).from_buffer(args)
rc = acl.aclrtLaunchKernel(func, 48, abuf, 32, stream)
print(f"[info] aclrtLaunchKernel rc={rc}")
if rc != 0: sys.exit(1)
ok(acl.aclrtSynchronizeStream(stream), "SyncStream")
ok(acl.aclrtMemcpy(z_h, nbytes, z_d, nbytes, D2H), "D2H z")

expected = [x_h[i] + y_h[i] for i in range(5)]
got = [z_h[i] for i in range(5)]
print(f"[result] expected first 5: {expected}")
print(f"[result] got first 5:      {got}")
match = sum(1 for i in range(N) if abs(z_h[i] - (x_h[i]+y_h[i])) < 1e-3)
print(f"[result] {match}/{N} match")

acl.aclrtFree(x_d); acl.aclrtFree(y_d); acl.aclrtFree(z_d)
acl.aclrtDestroyStream(stream); acl.aclrtResetDevice(0); acl.aclFinalize()
print("[done]")
