import ctypes, os, sys, struct
os.environ.setdefault("LD_LIBRARY_PATH", "/usr/local/Ascend/ascend-toolkit/latest/lib64")

acl = ctypes.CDLL("libascendcl.so")

# Minimal type sigs
acl.aclInit.argtypes = [ctypes.c_char_p]; acl.aclInit.restype = ctypes.c_int
acl.aclFinalize.argtypes = []; acl.aclFinalize.restype = ctypes.c_int
acl.aclrtSetDevice.argtypes = [ctypes.c_int]; acl.aclrtSetDevice.restype = ctypes.c_int
acl.aclrtResetDevice.argtypes = [ctypes.c_int]; acl.aclrtResetDevice.restype = ctypes.c_int
acl.aclrtCreateStream.argtypes = [ctypes.POINTER(ctypes.c_void_p)]; acl.aclrtCreateStream.restype = ctypes.c_int
acl.aclrtDestroyStream.argtypes = [ctypes.c_void_p]; acl.aclrtDestroyStream.restype = ctypes.c_int
acl.aclrtSynchronizeStream.argtypes = [ctypes.c_void_p]; acl.aclrtSynchronizeStream.restype = ctypes.c_int
acl.aclrtMalloc.argtypes = [ctypes.POINTER(ctypes.c_void_p), ctypes.c_size_t, ctypes.c_int]; acl.aclrtMalloc.restype = ctypes.c_int
acl.aclrtFree.argtypes = [ctypes.c_void_p]; acl.aclrtFree.restype = ctypes.c_int
acl.aclrtMemcpy.argtypes = [ctypes.c_void_p, ctypes.c_size_t, ctypes.c_void_p, ctypes.c_size_t, ctypes.c_int]; acl.aclrtMemcpy.restype = ctypes.c_int
acl.aclrtCreateBinary.argtypes = [ctypes.c_void_p, ctypes.c_size_t]; acl.aclrtCreateBinary.restype = ctypes.c_void_p
acl.aclrtDestroyBinary.argtypes = [ctypes.c_void_p]; acl.aclrtDestroyBinary.restype = ctypes.c_int
acl.aclrtBinaryLoad.argtypes = [ctypes.c_void_p, ctypes.POINTER(ctypes.c_void_p)]; acl.aclrtBinaryLoad.restype = ctypes.c_int
acl.aclrtBinaryGetFunction.argtypes = [ctypes.c_void_p, ctypes.c_char_p, ctypes.POINTER(ctypes.c_void_p)]; acl.aclrtBinaryGetFunction.restype = ctypes.c_int
acl.aclrtLaunchKernel.argtypes = [ctypes.c_void_p, ctypes.c_uint, ctypes.c_void_p, ctypes.c_size_t, ctypes.c_void_p]; acl.aclrtLaunchKernel.restype = ctypes.c_int

ACL_MEMCPY_HOST_TO_DEVICE = 1
ACL_MEMCPY_DEVICE_TO_HOST = 2
ACL_MEM_MALLOC_HUGE_FIRST = 0

def chk(r, what):
    if r != 0: print(f"[X] {what}: rc={r}"); sys.exit(1)
    print(f"[ok] {what}")

chk(acl.aclInit(None), "aclInit")
chk(acl.aclrtSetDevice(0), "aclrtSetDevice(0)")
stream = ctypes.c_void_p()
chk(acl.aclrtCreateStream(ctypes.byref(stream)), "aclrtCreateStream")

with open(sys.argv[1], "rb") as f: data = f.read()
print(f"[info] kernel bin size = {len(data)}")
bin_h = acl.aclrtCreateBinary(data, len(data))
print(f"[info] aclrtCreateBinary returned = {bin_h}")
if bin_h is None or bin_h == 0:
    print("[X] aclrtCreateBinary returned NULL"); sys.exit(1)

binHandle = ctypes.c_void_p()
rc = acl.aclrtBinaryLoad(bin_h, ctypes.byref(binHandle))
print(f"[info] aclrtBinaryLoad rc={rc}, binHandle={binHandle.value}")
if rc != 0: sys.exit(2)

funcHandle = ctypes.c_void_p()
rc = acl.aclrtBinaryGetFunction(binHandle, b"add_custom", ctypes.byref(funcHandle))
print(f"[info] aclrtBinaryGetFunction(add_custom) rc={rc}, func={funcHandle.value}")

# Try a few name variants if direct failed
for name in [b"add_custom", b"_Z10add_custommmmm", b"_Z10add_customPfS_S_m"]:
    fh = ctypes.c_void_p()
    rc = acl.aclrtBinaryGetFunction(binHandle, name, ctypes.byref(fh))
    print(f"  name={name.decode(errors='replace')[:60]}: rc={rc}, func={fh.value}")

acl.aclrtBinaryUnLoad = acl.__getattr__("aclrtBinaryUnLoad") if hasattr(acl, "aclrtBinaryUnLoad") else None
acl.aclFinalize()
print("[done]")
