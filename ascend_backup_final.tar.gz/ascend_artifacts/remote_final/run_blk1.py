import ctypes, sys, struct
acl = ctypes.CDLL("libascendcl.so")
for fn,at,rt in [("aclInit",[ctypes.c_char_p],ctypes.c_int),("aclrtSetDevice",[ctypes.c_int],ctypes.c_int),
    ("aclrtResetDevice",[ctypes.c_int],ctypes.c_int),("aclrtCreateStream",[ctypes.POINTER(ctypes.c_void_p)],ctypes.c_int),
    ("aclrtDestroyStream",[ctypes.c_void_p],ctypes.c_int),("aclrtSynchronizeStream",[ctypes.c_void_p],ctypes.c_int),
    ("aclrtMalloc",[ctypes.POINTER(ctypes.c_void_p),ctypes.c_size_t,ctypes.c_int],ctypes.c_int),
    ("aclrtFree",[ctypes.c_void_p],ctypes.c_int),
    ("aclrtMemcpy",[ctypes.c_void_p,ctypes.c_size_t,ctypes.c_void_p,ctypes.c_size_t,ctypes.c_int],ctypes.c_int),
    ("aclrtCreateBinary",[ctypes.c_void_p,ctypes.c_size_t],ctypes.c_void_p),
    ("aclrtBinaryLoad",[ctypes.c_void_p,ctypes.POINTER(ctypes.c_void_p)],ctypes.c_int),
    ("aclrtBinaryGetFunction",[ctypes.c_void_p,ctypes.c_char_p,ctypes.POINTER(ctypes.c_void_p)],ctypes.c_int),
    ("aclrtLaunchKernel",[ctypes.c_void_p,ctypes.c_uint,ctypes.c_void_p,ctypes.c_size_t,ctypes.c_void_p],ctypes.c_int),
    ("aclGetRecentErrMsg",[],ctypes.c_char_p)]:
    f=getattr(acl,fn); f.argtypes=at; f.restype=rt
acl.aclInit(None); acl.aclrtSetDevice(0)
s=ctypes.c_void_p(); acl.aclrtCreateStream(ctypes.byref(s))
with open(sys.argv[1],"rb") as f: d=f.read()
b=acl.aclrtCreateBinary(d,len(d))
h=ctypes.c_void_p(); acl.aclrtBinaryLoad(b,ctypes.byref(h))
fn_=ctypes.c_void_p(); acl.aclrtBinaryGetFunction(h,b"add_custom",ctypes.byref(fn_))

# tiny: 256 elements, blockDim=1
N=256; nb=N*4
x=(ctypes.c_float*N)(*[i*1.0 for i in range(N)])
y=(ctypes.c_float*N)(*[1.0 for _ in range(N)])
z=(ctypes.c_float*N)()
xd=ctypes.c_void_p(); acl.aclrtMalloc(ctypes.byref(xd),nb,0)
yd=ctypes.c_void_p(); acl.aclrtMalloc(ctypes.byref(yd),nb,0)
zd=ctypes.c_void_p(); acl.aclrtMalloc(ctypes.byref(zd),nb,0)
acl.aclrtMemcpy(xd,nb,x,nb,1); acl.aclrtMemcpy(yd,nb,y,nb,1)

for blocks in (1, 2, 4, 8, 24, 48):
    args=bytearray(32)
    struct.pack_into("QQQI",args,0,xd.value,yd.value,zd.value,N)
    ab=(ctypes.c_byte*32).from_buffer(args)
    rc=acl.aclrtLaunchKernel(fn_,blocks,ab,32,s)
    rc2=acl.aclrtSynchronizeStream(s)
    m=acl.aclGetRecentErrMsg(); m=m.decode()[:120] if m else ""
    print(f"blocks={blocks:3} launch={rc} sync={rc2} msg={m[:80]}")
    if rc2==0:
        acl.aclrtMemcpy(z,nb,zd,nb,2)
        match=sum(1 for i in range(N) if abs(z[i]-(x[i]+y[i]))<1e-3)
        print(f"    [OK] {match}/{N} first5={[z[i] for i in range(5)]}")
        break

acl.aclrtFree(xd); acl.aclrtFree(yd); acl.aclrtFree(zd)
acl.aclrtDestroyStream(s); acl.aclrtResetDevice(0)
