import ctypes, os, sys, struct

acl = ctypes.CDLL("libascendcl.so")
for fn, at, rt in [
    ("aclInit",[ctypes.c_char_p],ctypes.c_int), ("aclFinalize",[],ctypes.c_int),
    ("aclrtSetDevice",[ctypes.c_int],ctypes.c_int), ("aclrtResetDevice",[ctypes.c_int],ctypes.c_int),
    ("aclrtCreateStream",[ctypes.POINTER(ctypes.c_void_p)],ctypes.c_int),
    ("aclrtDestroyStream",[ctypes.c_void_p],ctypes.c_int),
    ("aclrtSynchronizeStream",[ctypes.c_void_p],ctypes.c_int),
    ("aclrtMalloc",[ctypes.POINTER(ctypes.c_void_p),ctypes.c_size_t,ctypes.c_int],ctypes.c_int),
    ("aclrtFree",[ctypes.c_void_p],ctypes.c_int),
    ("aclrtMemcpy",[ctypes.c_void_p,ctypes.c_size_t,ctypes.c_void_p,ctypes.c_size_t,ctypes.c_int],ctypes.c_int),
    ("aclrtCreateBinary",[ctypes.c_void_p,ctypes.c_size_t],ctypes.c_void_p),
    ("aclrtBinaryLoad",[ctypes.c_void_p,ctypes.POINTER(ctypes.c_void_p)],ctypes.c_int),
    ("aclrtBinaryGetFunction",[ctypes.c_void_p,ctypes.c_char_p,ctypes.POINTER(ctypes.c_void_p)],ctypes.c_int),
    ("aclrtLaunchKernel",[ctypes.c_void_p,ctypes.c_uint,ctypes.c_void_p,ctypes.c_size_t,ctypes.c_void_p],ctypes.c_int),
    ("aclrtLaunchKernelWithConfig",[ctypes.c_void_p,ctypes.c_uint,ctypes.c_void_p,ctypes.c_size_t,ctypes.c_void_p,ctypes.c_void_p],ctypes.c_int),
    ("aclrtGetLastError",[ctypes.c_int],ctypes.c_int),
    ("aclGetRecentErrMsg",[],ctypes.c_char_p),
]:
    f = getattr(acl, fn); f.argtypes=at; f.restype=rt

def ok(r, what):
    if r != 0:
        try: emsg = acl.aclGetRecentErrMsg()
        except: emsg = None
        print(f"[X] {what}: rc={r} emsg={emsg.decode() if emsg else None}"); sys.exit(1)

acl.aclInit(None); acl.aclrtSetDevice(0)
stream = ctypes.c_void_p(); acl.aclrtCreateStream(ctypes.byref(stream))

with open(sys.argv[1], "rb") as f: data = f.read()
bh = acl.aclrtCreateBinary(data, len(data))
binH = ctypes.c_void_p(); ok(acl.aclrtBinaryLoad(bh, ctypes.byref(binH)), "BinaryLoad")
func = ctypes.c_void_p(); ok(acl.aclrtBinaryGetFunction(binH, b"add_custom", ctypes.byref(func)), "GetFunction")

N = 48 * 256; nbytes = N * 4
x_h = (ctypes.c_float*N)(*[i*1.1 for i in range(N)])
y_h = (ctypes.c_float*N)(*[i+3.4 for i in range(N)])
z_h = (ctypes.c_float*N)()
x_d=ctypes.c_void_p(); acl.aclrtMalloc(ctypes.byref(x_d),nbytes,0)
y_d=ctypes.c_void_p(); acl.aclrtMalloc(ctypes.byref(y_d),nbytes,0)
z_d=ctypes.c_void_p(); acl.aclrtMalloc(ctypes.byref(z_d),nbytes,0)
acl.aclrtMemcpy(x_d,nbytes,x_h,nbytes,1); acl.aclrtMemcpy(y_d,nbytes,y_h,nbytes,1)

args = bytearray(32)
struct.pack_into("QQQI", args, 0, x_d.value, y_d.value, z_d.value, N)
abuf = (ctypes.c_byte*32).from_buffer(args)

# Try launch with config attrs: schemMode values 0..5
class Attr(ctypes.Structure):
    _fields_ = [("id", ctypes.c_int), ("schemMode", ctypes.c_uint8), ("pad", ctypes.c_uint8*23)]
class Cfg(ctypes.Structure):
    _fields_ = [("attrs", ctypes.POINTER(Attr)), ("numAttrs", ctypes.c_size_t)]

for blocks in (48, 1):
    for sm in (None, 0, 1, 2, 3):
        if sm is None:
            rc = acl.aclrtLaunchKernel(func, blocks, abuf, 32, stream)
            label = f"plain blocks={blocks}"
        else:
            at = Attr(); at.id = 1; at.schemMode = sm
            cfg = Cfg(); cfg.attrs = ctypes.pointer(at); cfg.numAttrs = 1
            rc = acl.aclrtLaunchKernelWithConfig(func, blocks, abuf, 32, stream, ctypes.byref(cfg))
            label = f"cfg schemMode={sm} blocks={blocks}"
        if rc != 0:
            print(f"[{label}] launch rc={rc}")
            continue
        rc2 = acl.aclrtSynchronizeStream(stream)
        emsg = acl.aclGetRecentErrMsg(); emsg = emsg.decode() if emsg else ""
        print(f"[{label}] launch=0 sync={rc2} msg={emsg[:150]}")
        if rc2 == 0:
            acl.aclrtMemcpy(z_h,nbytes,z_d,nbytes,2)
            ok_match = sum(1 for i in range(N) if abs(z_h[i] - (x_h[i]+y_h[i])) < 1e-3)
            print(f"    [result] {ok_match}/{N} matched first5={[z_h[i] for i in range(5)]}")
            if ok_match == N:
                print("    [SUCCESS] breaking")
                acl.aclrtFree(x_d); acl.aclrtFree(y_d); acl.aclrtFree(z_d)
                acl.aclrtDestroyStream(stream); acl.aclrtResetDevice(0); acl.aclFinalize()
                sys.exit(0)

acl.aclrtFree(x_d); acl.aclrtFree(y_d); acl.aclrtFree(z_d)
acl.aclrtDestroyStream(stream); acl.aclrtResetDevice(0); acl.aclFinalize()
