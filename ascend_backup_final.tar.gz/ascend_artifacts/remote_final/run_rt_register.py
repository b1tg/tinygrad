import ctypes, os, sys, struct

acl = ctypes.CDLL("libascendcl.so")
rt = ctypes.CDLL("libruntime.so")

RT_MAGIC_ELF = 0x43554245
RT_MAGIC_ELF_AIVEC = 0x41415246
RT_MAGIC_ELF_AICUBE = 0x41494343

class rtDevBinary_t(ctypes.Structure):
    _fields_ = [("magic", ctypes.c_uint32), ("version", ctypes.c_uint32),
                ("data", ctypes.c_void_p), ("length", ctypes.c_uint64)]

class rtArgsEx_t(ctypes.Structure):
    _fields_ = [("args", ctypes.c_void_p), ("hostInputInfoPtr", ctypes.c_void_p),
                ("argsSize", ctypes.c_uint32), ("tilingAddrOffset", ctypes.c_uint32),
                ("tilingDataOffset", ctypes.c_uint32), ("hostInputInfoNum", ctypes.c_uint16),
                ("hasTiling", ctypes.c_uint8), ("isNoNeedH2DCopy", ctypes.c_uint8),
                ("reserved", ctypes.c_uint8 * 4)]

for fn,at,rt_ in [("aclInit",[ctypes.c_char_p],ctypes.c_int),("aclrtSetDevice",[ctypes.c_int],ctypes.c_int),
    ("aclrtResetDevice",[ctypes.c_int],ctypes.c_int),("aclrtCreateStream",[ctypes.POINTER(ctypes.c_void_p)],ctypes.c_int),
    ("aclrtDestroyStream",[ctypes.c_void_p],ctypes.c_int),("aclrtSynchronizeStream",[ctypes.c_void_p],ctypes.c_int),
    ("aclrtMalloc",[ctypes.POINTER(ctypes.c_void_p),ctypes.c_size_t,ctypes.c_int],ctypes.c_int),
    ("aclrtFree",[ctypes.c_void_p],ctypes.c_int),
    ("aclrtMemcpy",[ctypes.c_void_p,ctypes.c_size_t,ctypes.c_void_p,ctypes.c_size_t,ctypes.c_int],ctypes.c_int),
    ("aclGetRecentErrMsg",[],ctypes.c_char_p)]:
    f=getattr(acl,fn); f.argtypes=at; f.restype=rt_

rt.rtRegisterAllKernel.argtypes = [ctypes.POINTER(rtDevBinary_t), ctypes.POINTER(ctypes.c_void_p)]
rt.rtRegisterAllKernel.restype = ctypes.c_int
rt.rtKernelLaunchWithHandle.argtypes = [ctypes.c_void_p, ctypes.c_uint64, ctypes.c_uint32,
    ctypes.POINTER(rtArgsEx_t), ctypes.c_void_p, ctypes.c_void_p, ctypes.c_void_p]
rt.rtKernelLaunchWithHandle.restype = ctypes.c_int
rt.rtVectorCoreKernelLaunchWithHandle.argtypes = [ctypes.c_void_p, ctypes.c_uint64, ctypes.c_uint32,
    ctypes.POINTER(rtArgsEx_t), ctypes.c_void_p, ctypes.c_void_p, ctypes.c_void_p]
rt.rtVectorCoreKernelLaunchWithHandle.restype = ctypes.c_int

def ok(r,w):
    if r!=0:
        m=acl.aclGetRecentErrMsg(); m=m.decode() if m else ""
        print(f"[X] {w} rc={r} {m[:200]}"); sys.exit(1)
    print(f"[ok] {w}")

acl.aclInit(None); acl.aclrtSetDevice(0)
s=ctypes.c_void_p(); acl.aclrtCreateStream(ctypes.byref(s))

with open(sys.argv[1],"rb") as f: data=f.read()
dbuf = (ctypes.c_ubyte * len(data)).from_buffer_copy(data)

for magic_name, magic in [("ELF", RT_MAGIC_ELF), ("ELF_AIVEC", RT_MAGIC_ELF_AIVEC), ("ELF_AICUBE", RT_MAGIC_ELF_AICUBE)]:
    bin_t = rtDevBinary_t(magic=magic, version=0, data=ctypes.cast(dbuf, ctypes.c_void_p), length=len(data))
    hdl = ctypes.c_void_p()
    rc = rt.rtRegisterAllKernel(ctypes.byref(bin_t), ctypes.byref(hdl))
    print(f"rtRegisterAllKernel(magic={magic_name:10}={magic:#x}) rc={rc} hdl={hdl.value}")
    if rc != 0: continue

    # prepare args
    N = 256; nb = N*4
    x_h = (ctypes.c_float*N)(*[i*1.0 for i in range(N)])
    y_h = (ctypes.c_float*N)(*[1.0 for _ in range(N)])
    z_h = (ctypes.c_float*N)()
    x_d = ctypes.c_void_p(); acl.aclrtMalloc(ctypes.byref(x_d), nb, 0)
    y_d = ctypes.c_void_p(); acl.aclrtMalloc(ctypes.byref(y_d), nb, 0)
    z_d = ctypes.c_void_p(); acl.aclrtMalloc(ctypes.byref(z_d), nb, 0)
    acl.aclrtMemcpy(x_d, nb, x_h, nb, 1); acl.aclrtMemcpy(y_d, nb, y_h, nb, 1)

    args_mem = bytearray(32)
    struct.pack_into("QQQI", args_mem, 0, x_d.value, y_d.value, z_d.value, N)
    args_arr = (ctypes.c_ubyte*32).from_buffer(args_mem)
    argsEx = rtArgsEx_t(args=ctypes.cast(args_arr, ctypes.c_void_p), hostInputInfoPtr=None,
                       argsSize=32, tilingAddrOffset=0, tilingDataOffset=0,
                       hostInputInfoNum=0, hasTiling=0, isNoNeedH2DCopy=0)

    # try both launch functions and various tiling keys
    for launch_name, launch_fn in [("VectorCore", rt.rtVectorCoreKernelLaunchWithHandle), ("Handle", rt.rtKernelLaunchWithHandle)]:
        for tk in (0, 0x7fffffff):
            rc = launch_fn(hdl, tk, 1, ctypes.byref(argsEx), None, s, None)
            rc2 = acl.aclrtSynchronizeStream(s)
            m = acl.aclGetRecentErrMsg(); m = m.decode()[:80] if m else ""
            print(f"  {launch_name}(tk={tk:#x}): launch={rc} sync={rc2} msg={m[:80]}")
            if rc2 == 0:
                acl.aclrtMemcpy(z_h, nb, z_d, nb, 2)
                match = sum(1 for i in range(N) if abs(z_h[i]-(x_h[i]+y_h[i]))<1e-3)
                print(f"    [RESULT] {match}/{N} first5={[z_h[i] for i in range(5)]}")
                if match == N:
                    print("    🎉 SUCCESS")
                    sys.exit(0)
    acl.aclrtFree(x_d); acl.aclrtFree(y_d); acl.aclrtFree(z_d)

acl.aclrtDestroyStream(s); acl.aclrtResetDevice(0)
