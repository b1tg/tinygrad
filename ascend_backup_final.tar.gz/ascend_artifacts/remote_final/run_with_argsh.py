import ctypes, os, sys, struct

acl = ctypes.CDLL("libascendcl.so")

for fn, at, rt in [
    ("aclInit",[ctypes.c_char_p],ctypes.c_int),("aclFinalize",[],ctypes.c_int),
    ("aclrtSetDevice",[ctypes.c_int],ctypes.c_int),("aclrtResetDevice",[ctypes.c_int],ctypes.c_int),
    ("aclrtCreateStream",[ctypes.POINTER(ctypes.c_void_p)],ctypes.c_int),
    ("aclrtDestroyStream",[ctypes.c_void_p],ctypes.c_int),
    ("aclrtSynchronizeStream",[ctypes.c_void_p],ctypes.c_int),
    ("aclrtMalloc",[ctypes.POINTER(ctypes.c_void_p),ctypes.c_size_t,ctypes.c_int],ctypes.c_int),
    ("aclrtFree",[ctypes.c_void_p],ctypes.c_int),
    ("aclrtMemcpy",[ctypes.c_void_p,ctypes.c_size_t,ctypes.c_void_p,ctypes.c_size_t,ctypes.c_int],ctypes.c_int),
    ("aclrtCreateBinary",[ctypes.c_void_p,ctypes.c_size_t],ctypes.c_void_p),
    ("aclrtBinaryLoad",[ctypes.c_void_p,ctypes.POINTER(ctypes.c_void_p)],ctypes.c_int),
    ("aclrtBinaryGetFunction",[ctypes.c_void_p,ctypes.c_char_p,ctypes.POINTER(ctypes.c_void_p)],ctypes.c_int),
    ("aclrtKernelArgsInit",[ctypes.c_void_p,ctypes.POINTER(ctypes.c_void_p)],ctypes.c_int),
    ("aclrtKernelArgsAppend",[ctypes.c_void_p,ctypes.c_void_p,ctypes.c_size_t,ctypes.POINTER(ctypes.c_void_p)],ctypes.c_int),
    ("aclrtKernelArgsFinalize",[ctypes.c_void_p],ctypes.c_int),
    ("aclrtLaunchKernelWithConfig",[ctypes.c_void_p,ctypes.c_uint,ctypes.c_void_p,ctypes.c_void_p,ctypes.c_void_p,ctypes.c_void_p],ctypes.c_int),
    ("aclGetRecentErrMsg",[],ctypes.c_char_p),
]:
    f = getattr(acl, fn); f.argtypes=at; f.restype=rt

def ok(r,w):
    if r!=0:
        m=acl.aclGetRecentErrMsg(); m=m.decode() if m else ""
        print(f"[X] {w} rc={r} {m[:200]}"); sys.exit(1)
    print(f"[ok] {w}")

acl.aclInit(None); acl.aclrtSetDevice(0)
stream=ctypes.c_void_p(); acl.aclrtCreateStream(ctypes.byref(stream))

with open(sys.argv[1],"rb") as f: data=f.read()
bh=acl.aclrtCreateBinary(data,len(data))
binH=ctypes.c_void_p(); ok(acl.aclrtBinaryLoad(bh,ctypes.byref(binH)),"BinaryLoad")
func=ctypes.c_void_p(); ok(acl.aclrtBinaryGetFunction(binH,b"add_custom",ctypes.byref(func)),"GetFunction")

# allocate + memcpy
N=48*256; nbytes=N*4
x_h=(ctypes.c_float*N)(*[i*1.1 for i in range(N)])
y_h=(ctypes.c_float*N)(*[i+3.4 for i in range(N)])
z_h=(ctypes.c_float*N)()
x_d=ctypes.c_void_p(); acl.aclrtMalloc(ctypes.byref(x_d),nbytes,0)
y_d=ctypes.c_void_p(); acl.aclrtMalloc(ctypes.byref(y_d),nbytes,0)
z_d=ctypes.c_void_p(); acl.aclrtMalloc(ctypes.byref(z_d),nbytes,0)
acl.aclrtMemcpy(x_d,nbytes,x_h,nbytes,1); acl.aclrtMemcpy(y_d,nbytes,y_h,nbytes,1)

# Use Args handle path
argsH = ctypes.c_void_p()
ok(acl.aclrtKernelArgsInit(func, ctypes.byref(argsH)), "ArgsInit")

# append each arg
for name, val, size in [("x", x_d, 8), ("y", y_d, 8), ("z", z_d, 8), ("n", ctypes.c_uint32(N), 4)]:
    ph = ctypes.c_void_p()
    if isinstance(val, ctypes.c_void_p):
        p = ctypes.byref(val)
    else:
        p = ctypes.byref(val)
    ok(acl.aclrtKernelArgsAppend(argsH, p, size, ctypes.byref(ph)), f"ArgsAppend({name})")

ok(acl.aclrtKernelArgsFinalize(argsH), "ArgsFinalize")

# Launch with config
rc = acl.aclrtLaunchKernelWithConfig(func, 48, stream, None, argsH, None)
print(f"[info] LaunchKernelWithConfig rc={rc}")
if rc != 0:
    m=acl.aclGetRecentErrMsg(); m=m.decode() if m else ""
    print(f"    msg: {m[:300]}")
else:
    rc2 = acl.aclrtSynchronizeStream(stream)
    print(f"[info] Sync rc={rc2}")
    if rc2 == 0:
        acl.aclrtMemcpy(z_h, nbytes, z_d, nbytes, 2)
        match = sum(1 for i in range(N) if abs(z_h[i]-(x_h[i]+y_h[i]))<1e-3)
        print(f"[result] {match}/{N} match, first5: {[z_h[i] for i in range(5)]}")
    else:
        m=acl.aclGetRecentErrMsg(); m=m.decode() if m else ""
        print(f"    msg: {m[:300]}")

acl.aclrtFree(x_d); acl.aclrtFree(y_d); acl.aclrtFree(z_d)
acl.aclrtDestroyStream(stream); acl.aclrtResetDevice(0); acl.aclFinalize()
