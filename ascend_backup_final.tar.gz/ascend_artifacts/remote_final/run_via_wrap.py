import ctypes, os, sys, struct

acl = ctypes.CDLL("libascendcl.so")
wrap = ctypes.CDLL("/root/tg_probe/asc_wrap.so")

for fn,at,rt in [("aclInit",[ctypes.c_char_p],ctypes.c_int),("aclrtSetDevice",[ctypes.c_int],ctypes.c_int),
    ("aclrtResetDevice",[ctypes.c_int],ctypes.c_int),("aclrtCreateStream",[ctypes.POINTER(ctypes.c_void_p)],ctypes.c_int),
    ("aclrtDestroyStream",[ctypes.c_void_p],ctypes.c_int),("aclrtSynchronizeStream",[ctypes.c_void_p],ctypes.c_int),
    ("aclrtMalloc",[ctypes.POINTER(ctypes.c_void_p),ctypes.c_size_t,ctypes.c_int],ctypes.c_int),
    ("aclrtFree",[ctypes.c_void_p],ctypes.c_int),
    ("aclrtMemcpy",[ctypes.c_void_p,ctypes.c_size_t,ctypes.c_void_p,ctypes.c_size_t,ctypes.c_int],ctypes.c_int),
    ("aclGetRecentErrMsg",[],ctypes.c_char_p)]:
    f=getattr(acl,fn); f.argtypes=at; f.restype=rt

wrap.my_register.argtypes = [ctypes.c_char_p, ctypes.c_size_t, ctypes.c_uint32, ctypes.POINTER(ctypes.c_void_p)]
wrap.my_register.restype = ctypes.c_int
wrap.my_launch.argtypes = [ctypes.c_void_p, ctypes.c_uint64, ctypes.c_uint32, ctypes.POINTER(ctypes.c_void_p), ctypes.c_uint32, ctypes.c_void_p]
wrap.my_launch.restype = ctypes.c_int
wrap.my_launch_vec.argtypes = [ctypes.c_void_p, ctypes.c_uint64, ctypes.POINTER(ctypes.c_void_p), ctypes.c_uint32, ctypes.c_void_p, ctypes.c_uint32]
wrap.my_launch_vec.restype = ctypes.c_int
wrap.my_unregister.argtypes = [ctypes.c_void_p]
wrap.my_unregister.restype = ctypes.c_int

acl.aclInit(None); acl.aclrtSetDevice(0)
s=ctypes.c_void_p(); acl.aclrtCreateStream(ctypes.byref(s))

with open(sys.argv[1],"rb") as f: data=f.read()
dbuf = ctypes.c_char_p(data)

# type 1 = AIV
hdl = ctypes.c_void_p()
rc = wrap.my_register(dbuf, len(data), 1, ctypes.byref(hdl))
m = acl.aclGetRecentErrMsg(); m = m.decode()[:200] if m else ""
print(f"my_register(type=1 AIV) rc={rc} hdl={hdl.value} msg={m}")
if rc != 0: sys.exit(1)

# allocate + memcpy
N=256; nb=N*4
x_h=(ctypes.c_float*N)(*[i*1.0 for i in range(N)])
y_h=(ctypes.c_float*N)(*[1.0 for _ in range(N)])
z_h=(ctypes.c_float*N)()
x_d=ctypes.c_void_p(); acl.aclrtMalloc(ctypes.byref(x_d),nb,0)
y_d=ctypes.c_void_p(); acl.aclrtMalloc(ctypes.byref(y_d),nb,0)
z_d=ctypes.c_void_p(); acl.aclrtMalloc(ctypes.byref(z_d),nb,0)
acl.aclrtMemcpy(x_d,nb,x_h,nb,1); acl.aclrtMemcpy(y_d,nb,y_h,nb,1)

# Args format: void** — each element points to its arg
# For add_custom(x, y, z, n): 4 elements
n_val = ctypes.c_uint32(N)
arg_ptrs = (ctypes.c_void_p * 4)(x_d, y_d, z_d, ctypes.cast(ctypes.byref(n_val), ctypes.c_void_p))
argssize = 32  # from __CCE_KernelArgSize

for blocks in (1, 8, 24, 48):
    rc = wrap.my_launch(hdl, 0, blocks, arg_ptrs, argssize, s)
    m = acl.aclGetRecentErrMsg(); m = m.decode()[:80] if m else ""
    print(f"my_launch(tk=0 blocks={blocks}) rc={rc}")
    if rc != 0: continue
    rc2 = acl.aclrtSynchronizeStream(s)
    m = acl.aclGetRecentErrMsg(); m = m.decode()[:150] if m else ""
    print(f"  sync rc={rc2} msg={m}")
    if rc2 == 0:
        acl.aclrtMemcpy(z_h,nb,z_d,nb,2)
        match=sum(1 for i in range(N) if abs(z_h[i]-(x_h[i]+y_h[i]))<1e-3)
        print(f"  🎉 {match}/{N} first5={[z_h[i] for i in range(5)]}")
        if match==N: break

wrap.my_unregister(hdl)
acl.aclrtFree(x_d); acl.aclrtFree(y_d); acl.aclrtFree(z_d)
acl.aclrtDestroyStream(s); acl.aclrtResetDevice(0)
