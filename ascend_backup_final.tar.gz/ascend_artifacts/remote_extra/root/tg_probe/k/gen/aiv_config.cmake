set(MIX_SOURCES
)
set(AIV_SOURCES
    /root/tg_probe/k/gen/auto_gen_add_simple.cce
)
set_source_files_properties(/root/tg_probe/k/gen/auto_gen_add_simple.cce
    PROPERTIES COMPILE_DEFINITIONS ";auto_gen_add_custom_kernel=add_custom;ONE_CORE_DUMP_SIZE=1048576"
)
