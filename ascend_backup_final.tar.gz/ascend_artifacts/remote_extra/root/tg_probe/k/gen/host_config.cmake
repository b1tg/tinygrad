set_source_files_properties(/root/tg_probe/k/add_simple.cce
    PROPERTIES COMPILE_DEFINITIONS "ONE_CORE_DUMP_SIZE=1048576"
)
